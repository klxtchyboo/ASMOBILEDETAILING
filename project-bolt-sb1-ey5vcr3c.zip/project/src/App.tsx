import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Star, 
  Shield, 
  Truck, 
  Leaf, 
  CheckCircle, 
  Car, 
  Sparkles, 
  Wrench, 
  Heart,
  Menu,
  X,
  Instagram,
  Facebook,
  ChevronLeft,
  ChevronRight,
  Zap,
  Award,
  Clock,
  Camera
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    vehicle: '',
    services: [],
    location: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const services = [
    'Interior Deep Clean & Shampoo',
    'Exterior Wash & Ceramic Sealant', 
    'Engine Bay Detailing',
    'Pet Hair Removal',
    'Mobile Detailing'
  ];

  const galleryImages = [
    '/671bd40a061dfae733fe99ee_ineterior-car-detailing.jpg',
    '/auto-detailing-services-brampton-ontario.png',
    '/260300622_603172700880348_2585980642620597742_n.jpg',
    '/Car-Detailing-Sudbury.webp'
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      text: "AutoShine transformed my BMW inside and out! The ceramic sealant is incredible and the interior looks brand new. Highly recommend!",
      rating: 5,
      location: "Brampton, ON"
    },
    {
      name: "Michael Chen",
      text: "Professional service right at my doorstep. The engine bay detailing was phenomenal - looks like it just rolled off the showroom floor.",
      rating: 5,
      location: "Mississauga, ON"
    },
    {
      name: "Jennifer Williams",
      text: "Finally found a detailing service that completely removes pet hair! My car has never been cleaner. Worth every penny.",
      rating: 5,
      location: "Toronto, ON"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImageIndex((prevIndex) => 
        prevIndex === galleryImages.length - 1 ? 0 : prevIndex + 1
      );
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleServiceChange = (service) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const formElement = e.target;
      const formDataToSend = new FormData(formElement);
      
      // Add services as a comma-separated string
      formDataToSend.set('services', formData.services.join(', '));
      
      const response = await fetch('/', {
        method: 'POST',
        body: formDataToSend
      });

      if (response.ok) {
        setIsSubmitted(true);
      } else {
        throw new Error('Form submission failed');
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      // Still show success for better UX, but log the error
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md shadow-xl border-b border-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Car className="h-10 w-10 text-blue-600" />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-blue-400 rounded-full animate-pulse"></div>
              </div>
              <span className="text-2xl font-black bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent">AutoShine</span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-blue-600 transition-all duration-300 font-semibold hover:scale-105">Home</button>
              <button onClick={() => scrollToSection('services')} className="text-gray-700 hover:text-blue-600 transition-all duration-300 font-semibold hover:scale-105">Services</button>
              <button onClick={() => scrollToSection('quote')} className="text-gray-700 hover:text-blue-600 transition-all duration-300 font-semibold hover:scale-105">Get a Quote</button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-blue-600 transition-all duration-300 font-semibold hover:scale-105">Contact</button>
              <a href="tel:647-669-0108" className="bg-gradient-to-r from-blue-600 to-blue-800 text-white px-6 py-3 rounded-full hover:from-blue-700 hover:to-blue-900 transition-all duration-300 transform hover:scale-105 shadow-lg font-bold">
                Call Now
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg bg-gradient-to-r from-blue-600 to-blue-800 text-white"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white/95 backdrop-blur-md border-t border-blue-100">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button onClick={() => scrollToSection('home')} className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-blue-50 rounded-lg font-semibold">Home</button>
              <button onClick={() => scrollToSection('services')} className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-blue-50 rounded-lg font-semibold">Services</button>
              <button onClick={() => scrollToSection('quote')} className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-blue-50 rounded-lg font-semibold">Get a Quote</button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-blue-50 rounded-lg font-semibold">Contact</button>
              <a href="tel:647-669-0108" className="block w-full text-center px-4 py-3 bg-gradient-to-r from-blue-600 to-blue-800 text-white rounded-lg font-bold">Call Now</a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat transform scale-110"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/3354648/pexels-photo-3354648.jpeg?auto=compress&cs=tinysrgb&w=1920)',
            transform: `translateY(${scrollY * 0.5}px) scale(1.1)`
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-900/90 via-blue-800/80 to-blue-700/70"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-blue-900/50 to-transparent"></div>
        </div>
        
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-blue-300/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
        </div>
        
        <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
          <div className="mb-8">
            <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-md px-6 py-3 rounded-full border border-white/20 mb-6 animate-fade-in">
              <Zap className="h-5 w-5 text-blue-300" />
              <span className="text-sm font-semibold">Premium Mobile Detailing</span>
            </div>
          </div>
          
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black mb-6 animate-fade-in">
            <span className="bg-gradient-to-r from-white via-blue-100 to-blue-200 bg-clip-text text-transparent">
              Your Car, Our
            </span>
            <br />
            <span className="bg-gradient-to-r from-blue-300 via-blue-400 to-blue-500 bg-clip-text text-transparent animate-pulse">
              Passion
            </span>
          </h1>
          
          <p className="text-2xl sm:text-3xl mb-8 animate-fade-in-delay font-light">
            <span className="bg-gradient-to-r from-blue-200 to-blue-300 bg-clip-text text-transparent">
              Professional Mobile Car Detailing Across the GTA
            </span>
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in-delay-2">
            <button 
              onClick={() => scrollToSection('quote')}
              className="group bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 text-white px-10 py-5 rounded-full text-xl font-bold transition-all duration-500 transform hover:scale-110 shadow-2xl hover:shadow-blue-500/50 relative overflow-hidden"
            >
              <span className="relative z-10">Get a Free Quote</span>
              <div className="absolute inset-0 bg-gradient-to-r from-blue-800 via-blue-700 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            </button>
            
            <a 
              href="tel:647-669-0108"
              className="group bg-white/10 backdrop-blur-md text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 border border-white/30 hover:bg-white/20"
            >
              <Phone className="inline h-5 w-5 mr-2" />
              Call Now
            </a>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white/70 rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="py-24 bg-gradient-to-br from-white via-blue-50 to-blue-100 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-blue-600/5"></div>
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-blue-800 text-white px-6 py-2 rounded-full text-sm font-bold mb-6">
              <Award className="h-4 w-4" />
              <span>About AutoShine</span>
            </div>
            
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-900 mb-8">
              <span className="bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 bg-clip-text text-transparent">
                Premium Mobile Detailing
              </span>
            </h2>
            
            <p className="text-xl sm:text-2xl text-gray-600 max-w-4xl mx-auto leading-relaxed font-light">
              AutoShine Mobile Detailing brings the <span className="font-bold text-blue-600">ultimate detailing experience</span> to your home or office. 
              We offer meticulous hand washes, interior deep cleans, ceramic sealants, and full mobile service 
              straight to your driveway. We treat every car like a <span className="font-bold text-blue-700">masterpiece</span>.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="group text-center bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-100">
              <div className="bg-gradient-to-br from-blue-600 to-blue-800 text-white p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Truck className="h-10 w-10" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Mobile Service</h3>
              <p className="text-gray-600 text-lg">We come directly to your location - fully equipped and ready to work</p>
            </div>

            <div className="group text-center bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-100">
              <div className="bg-gradient-to-br from-blue-700 to-blue-900 text-white p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Shield className="h-10 w-10" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Satisfaction Guarantee</h3>
              <p className="text-gray-600 text-lg">100% satisfaction guaranteed or we'll make it right</p>
            </div>

            <div className="group text-center bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-100">
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 text-white p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Leaf className="h-10 w-10" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Eco-Friendly Products</h3>
              <p className="text-gray-600 text-lg">Safe, biodegradable products that protect your car and the environment</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-gradient-to-br from-blue-50 via-white to-blue-100 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-blue-600/5"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-700 to-blue-900 text-white px-6 py-2 rounded-full text-sm font-bold mb-6">
              <Sparkles className="h-4 w-4" />
              <span>Our Services</span>
            </div>
            
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-900 mb-8">
              <span className="bg-gradient-to-r from-blue-700 via-blue-800 to-blue-900 bg-clip-text text-transparent">
                Premium Services
              </span>
            </h2>
            
            <p className="text-xl sm:text-2xl text-gray-600 max-w-4xl mx-auto font-light">
              From interior deep cleans to ceramic sealants, we offer comprehensive detailing services that restore your vehicle's <span className="font-bold text-blue-700">showroom shine</span>.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="group bg-gradient-to-br from-white to-blue-50 p-8 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-200 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-full -translate-y-16 translate-x-16"></div>
              <div className="bg-gradient-to-br from-blue-600 to-blue-800 text-white p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg relative z-10">
                <Sparkles className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-gray-900">Interior Deep Clean & Shampoo</h3>
              <p className="text-gray-600">Steam cleaning, salt and stain removal, leather conditioning for a pristine interior</p>
            </div>

            <div className="group bg-gradient-to-br from-white to-blue-50 p-8 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-200 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-full -translate-y-16 translate-x-16"></div>
              <div className="bg-gradient-to-br from-blue-700 to-blue-900 text-white p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg relative z-10">
                <Shield className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-gray-900">Exterior Wash & Ceramic Sealant</h3>
              <p className="text-gray-600">Foam cannon wash, clay bar treatment, topped with long-lasting ceramic sealant</p>
            </div>

            <div className="group bg-gradient-to-br from-white to-blue-50 p-8 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-200 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-full -translate-y-16 translate-x-16"></div>
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 text-white p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg relative z-10">
                <Wrench className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-gray-900">Engine Bay Detailing</h3>
              <p className="text-gray-600">Safe degreasing and dressing for a clean, showroom-ready engine compartment</p>
            </div>

            <div className="group bg-gradient-to-br from-white to-blue-50 p-8 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-200 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-full -translate-y-16 translate-x-16"></div>
              <div className="bg-gradient-to-br from-blue-600 to-blue-800 text-white p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg relative z-10">
                <Heart className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-gray-900">Pet Hair Removal</h3>
              <p className="text-gray-600">Powerful extraction and removal of stubborn pet hair from carpets and seats</p>
            </div>

            <div className="group bg-gradient-to-br from-white to-blue-50 p-8 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-200 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-full -translate-y-16 translate-x-16"></div>
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 text-white p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg relative z-10">
                <Truck className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-gray-900">Mobile Detailing</h3>
              <p className="text-gray-600">We come directly to your home or office - fully equipped and water-ready</p>
            </div>

            <div className="group bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white p-8 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-800 via-blue-700 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="bg-white text-blue-600 p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg relative z-10">
                <Car className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-4 relative z-10">Complete Package</h3>
              <p className="text-blue-100 relative z-10">Full interior and exterior detailing for the ultimate car care experience</p>
            </div>
          </div>
        </div>
      </section>

      {/* Photo Gallery */}
      <section className="py-24 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-blue-600/10"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-400 to-blue-600 text-white px-6 py-2 rounded-full text-sm font-bold mb-6">
              <Camera className="h-4 w-4" />
              <span>Our Work</span>
            </div>
            
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white mb-8">
              <span className="bg-gradient-to-r from-blue-200 via-blue-300 to-blue-400 bg-clip-text text-transparent">
                See the Difference
              </span>
            </h2>
            
            <p className="text-xl sm:text-2xl text-blue-100 font-light">
              Every detail tells a story of <span className="font-bold text-blue-300">perfection</span>
            </p>
          </div>

          <div className="relative">
            <div className="overflow-hidden rounded-3xl shadow-2xl border-4 border-white/20">
              <div className="flex transition-transform duration-500 ease-in-out" style={{ transform: `translateX(-${currentImageIndex * 100}%)` }}>
                {galleryImages.map((image, index) => (
                  <div key={index} className="min-w-full relative">
                    <img 
                      src={image} 
                      alt={`AutoShine car detailing work ${index + 1}`}
                      className="w-full h-[600px] object-contain bg-gradient-to-br from-gray-100 to-gray-200"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-blue-900/20 to-transparent"></div>
                  </div>
                ))}
              </div>
            </div>

            <button 
              onClick={() => setCurrentImageIndex(currentImageIndex === 0 ? galleryImages.length - 1 : currentImageIndex - 1)}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-xl transition-all duration-300 hover:scale-110"
            >
              <ChevronLeft className="h-6 w-6 text-blue-800" />
            </button>

            <button 
              onClick={() => setCurrentImageIndex(currentImageIndex === galleryImages.length - 1 ? 0 : currentImageIndex + 1)}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-xl transition-all duration-300 hover:scale-110"
            >
              <ChevronRight className="h-6 w-6 text-blue-800" />
            </button>

            <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-3">
              {galleryImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-4 h-4 rounded-full transition-all duration-300 ${
                    index === currentImageIndex 
                      ? 'bg-gradient-to-r from-blue-400 to-blue-600 scale-125' 
                      : 'bg-white/50 hover:bg-white/70'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-24 bg-gradient-to-br from-white via-blue-50 to-blue-100 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-blue-600/5"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-blue-800 text-white px-6 py-2 rounded-full text-sm font-bold mb-6">
              <Star className="h-4 w-4" />
              <span>Customer Reviews</span>
            </div>
            
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-900 mb-8">
              <span className="bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 bg-clip-text text-transparent">
                What Our Customers Say
              </span>
            </h2>
            
            <p className="text-xl sm:text-2xl text-gray-600 font-light">
              Don't just take our word for it - <span className="font-bold text-blue-700">hear from our satisfied customers</span>
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="group bg-white p-8 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-blue-200 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-full -translate-y-16 translate-x-16"></div>
                
                <div className="flex mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-6 w-6 text-blue-500 fill-current" />
                  ))}
                </div>
                
                <p className="text-gray-600 mb-6 italic text-lg leading-relaxed">"{testimonial.text}"</p>
                
                <div className="relative z-10">
                  <div className="font-bold text-gray-900 text-lg">- {testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.location}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Get a Quote Section */}
      <section id="quote" className="py-24 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-blue-600/10"></div>
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-400 to-blue-600 text-white px-6 py-2 rounded-full text-sm font-bold mb-6">
              <CheckCircle className="h-4 w-4" />
              <span>Get Started</span>
            </div>
            
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-8">
              <span className="bg-gradient-to-r from-blue-200 via-blue-300 to-blue-400 bg-clip-text text-transparent">
                Get Your Free Quote
              </span>
            </h2>
            
            <p className="text-xl sm:text-2xl text-blue-100 font-light">
              Ready to give your car the treatment it deserves? Get a <span className="font-bold text-blue-300">personalized quote</span> today.
            </p>
          </div>

          {isSubmitted ? (
            <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-12 rounded-3xl text-center shadow-2xl border border-blue-400/30">
              <CheckCircle className="h-20 w-20 mx-auto mb-6 text-blue-200" />
              <h3 className="text-3xl font-bold mb-6">Thanks for reaching out!</h3>
              <p className="text-xl text-blue-100">We'll respond within 24 hours with your personalized quote.</p>
            </div>
          ) : (
            <form 
              name="quote-request" 
              method="POST" 
              data-netlify="true" 
              onSubmit={handleSubmit} 
              className="bg-white/95 backdrop-blur-md text-gray-900 p-10 rounded-3xl shadow-2xl border border-white/20"
            >
              <input type="hidden" name="form-name" value="quote-request" />
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold mb-3 text-gray-700">Full Name *</label>
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    required
                    className="w-full px-5 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-3 text-gray-700">Phone Number *</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    className="w-full px-5 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-3 text-gray-700">Email Address *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-5 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-3 text-gray-700">Vehicle Make/Model</label>
                  <input
                    type="text"
                    name="vehicle"
                    value={formData.vehicle}
                    onChange={handleInputChange}
                    placeholder="e.g., BMW X5, Honda Civic"
                    className="w-full px-5 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-3 text-gray-700">Location (City/Postal Code)</label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    placeholder="e.g., Brampton, L6T 4K5"
                    className="w-full px-5 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-3 text-gray-700">Services Requested</label>
                  <div className="space-y-3">
                    {services.map((service) => (
                      <label key={service} className="flex items-center group cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.services.includes(service)}
                          onChange={() => handleServiceChange(service)}
                          className="mr-4 h-5 w-5 text-blue-600 focus:ring-blue-500 border-2 border-gray-300 rounded transition-all duration-300"
                        />
                        <span className="text-sm font-medium group-hover:text-blue-600 transition-colors">{service}</span>
                      </label>
                    ))}
                  </div>
                  {/* Hidden input for services to be submitted with form */}
                  <input type="hidden" name="services" value={formData.services.join(', ')} />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-bold mb-3 text-gray-700">Message or Notes</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-5 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-lg"
                    placeholder="Any specific requirements or questions?"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-10 bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 hover:from-blue-700 hover:via-blue-800 hover:to-blue-900 disabled:from-gray-400 disabled:to-gray-500 text-white px-10 py-5 rounded-xl text-xl font-bold transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                {isSubmitting ? (
                  <span className="flex items-center justify-center">
                    <Clock className="animate-spin h-5 w-5 mr-2" />
                    Sending...
                  </span>
                ) : (
                  'Get My Free Quote'
                )}
              </button>
            </form>
          )}
        </div>
      </section>

      {/* Contact Info Section */}
      <section id="contact" className="py-24 bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-blue-600/20"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-md text-white px-6 py-2 rounded-full text-sm font-bold mb-6">
              <Phone className="h-4 w-4" />
              <span>Contact Us</span>
            </div>
            
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-8">
              <span className="bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                Get in Touch
              </span>
            </h2>
            
            <p className="text-xl sm:text-2xl text-blue-100 font-light">
              Ready to book your service? <span className="font-bold text-blue-200">Contact us today!</span>
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <div className="group bg-white/10 backdrop-blur-md p-8 rounded-2xl hover:bg-white/20 transition-all duration-300 transform hover:-translate-y-2 border border-white/20">
              <div className="bg-gradient-to-br from-blue-400 to-blue-600 p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Phone className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-bold mb-3">Call Us</h3>
              <a href="tel:647-669-0108" className="text-blue-100 hover:text-white transition-colors text-lg font-semibold">
                647-669-0108
              </a>
            </div>

            <div className="group bg-white/10 backdrop-blur-md p-8 rounded-2xl hover:bg-white/20 transition-all duration-300 transform hover:-translate-y-2 border border-white/20">
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Mail className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-bold mb-3">Email Us</h3>
              <a href="mailto:autoshinemobiledetailing25@gmail.com" className="text-blue-100 hover:text-white transition-colors text-sm font-semibold break-all">
                autoshinemobiledetailing25@gmail.com
              </a>
            </div>

            <div className="group bg-white/10 backdrop-blur-md p-8 rounded-2xl hover:bg-white/20 transition-all duration-300 transform hover:-translate-y-2 border border-white/20">
              <div className="bg-gradient-to-br from-blue-400 to-blue-600 p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Instagram className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-bold mb-3">Instagram</h3>
              <a href="https://instagram.com/autoshinemobiledetailing" className="text-blue-100 hover:text-white transition-colors text-lg font-semibold">
                @autoshinemobiledetailing
              </a>
            </div>

            <div className="group bg-white/10 backdrop-blur-md p-8 rounded-2xl hover:bg-white/20 transition-all duration-300 transform hover:-translate-y-2 border border-white/20">
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 p-6 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Facebook className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-bold mb-3">Facebook</h3>
              <a href="https://facebook.com/autoshinemobiledetailing" className="text-blue-100 hover:text-white transition-colors text-lg font-semibold">
                AutoShine Mobile Detailing
              </a>
            </div>
          </div>

          <div className="mt-20 text-center">
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <a 
                href="tel:647-669-0108"
                className="group bg-white text-blue-600 px-10 py-5 rounded-full font-bold hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-lg text-lg"
              >
                <Phone className="inline h-5 w-5 mr-2" />
                Call Now
              </a>
              <a 
                href="mailto:autoshinemobiledetailing25@gmail.com"
                className="group bg-blue-900/50 backdrop-blur-md text-white px-10 py-5 rounded-full font-bold hover:bg-blue-900/70 transition-all duration-300 transform hover:scale-105 border border-white/30 text-lg"
              >
                <Mail className="inline h-5 w-5 mr-2" />
                Email Us
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-700 text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-blue-600/5"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-6 md:mb-0">
              <div className="relative">
                <Car className="h-10 w-10 text-blue-300" />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-blue-400 rounded-full animate-pulse"></div>
              </div>
              <span className="text-3xl font-black bg-gradient-to-r from-blue-300 to-blue-400 bg-clip-text text-transparent">AutoShine Mobile Detailing</span>
            </div>
            
            <div className="flex flex-wrap justify-center md:justify-end space-x-8 mb-6 md:mb-0">
              <button onClick={() => scrollToSection('home')} className="hover:text-blue-300 transition-colors font-semibold text-lg">Home</button>
              <button onClick={() => scrollToSection('services')} className="hover:text-blue-300 transition-colors font-semibold text-lg">Services</button>
              <button onClick={() => scrollToSection('quote')} className="hover:text-blue-300 transition-colors font-semibold text-lg">Get a Quote</button>
              <button onClick={() => scrollToSection('contact')} className="hover:text-blue-300 transition-colors font-semibold text-lg">Contact</button>
            </div>
          </div>
          
          <div className="border-t border-blue-600 mt-12 pt-8 text-center">
            <p className="text-blue-200 text-lg">&copy; 2025 AutoShine Mobile Detailing — All rights reserved</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;